This directory contains some small modifications/additions to
netlab, http://www.ncrg.aston.ac.uk/netlab/.

- gmmem2 allows a prior on the covariance, and lets you visualize
intermediate results of the learning
- gmmem_multi_restart is self-explanatory

All the _weighted functions were written by Pierpaolo Brutti.
They are needed by BNT (softmax_CPD  and mlp_CPD
maximize_params method).
