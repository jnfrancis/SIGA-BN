function r = bntRoot()
% Return directory name where bnt is stored
    r = fileparts(which(mfilename));
end
