Graph theory toolbox.
All functions written by Kevin Murphy (1998) unless otherwise noted.
The latest version is available from http://www.ai.mit.edu/~murphyk/Software/index.html
