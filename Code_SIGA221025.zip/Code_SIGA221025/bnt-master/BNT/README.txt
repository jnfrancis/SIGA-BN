The Bayes Net Toolbox for Matlab was written by Kevin Patrick Murphy et al.
This version was last updated on 17 Oct 2007..
To download the latest version, and to get documentation, please go to
   http://www.cs.ubc.ca/~murphyk/Software/BNT/bnt.html
