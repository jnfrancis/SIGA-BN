%% Main 将不同的 Algo 放在一起对比，挨个跑
dbstop if error
addpath(genpath(pwd));          % 搜索子目录的子程序
addpath(genpath('D:\WorkSpace-Project\BNC-PSO-others\bnt-master\'));
%addpath(genpath('/Users/wyl/Desktop/Ykf_bnet_study_20220610'));
% rmpath('D:\WorkSpace-Project\Ykf_bnet_study\comparison_algo\causal_explorer');
% 主要参数
N    = 100;                     % population size        种群大小
MP   = 4;                       % max parents/in-degree  最大父集 max 7
fxda = 0.9;                     % threshold of a         参数a的固定值
tour = 4;                       % tournament size        锦标赛规模

%scoring_fn = 'bic';             % scoring function for S&S phase
 scoring_fn = 'bayesian';      % SIGA用这个
% scoring_fn = 'mit';

%% ================================================= 生成新的数据集
DsNL = cell(0,0);DsS = cell(0,0);   % DatasetNameList & DatasetSize
% ========================================================== 数据集
  DsNL{end+1} = 'Asia';           DsS(end+1) = { [500] };

for i = 1:size(DsNL,2)
    Try = 20;                       % 尝试的次数 - 论文对比(生成数据集)
    gen_new_dataset(DsS{i},DsNL{i},Try);      % 记得修改 Try
end

%% ====================================================== 批量运行 
M4Small = 100; M4Medium = 100; M4Large = 100; M4VLarge = 100;


                        Try = 20;                     % 尝试的次数 - 论文对比


% ========================================================================= Asia
bnet = mk_asia_bnet;    dsn = 'Asia';	net = 'As';   M = M4Small;
% ===================================================== ↑单独设置，↓都一样
Algo = cell(0,0);DsS = cell(0,0);  % AlgorithmList & Dataset Size
% ===========     算法    ======    数据集大小      ==========
% Algo{end+1} = 'std_score';      DsS(end+1) = { [500] };
Algo{end+1} = 'SIGA';           DsS(end+1) = { [500] };


for i = 1:size(Algo,2)
     execute_algo(Algo{i},DsS{i},dsn,net,N,M,MP,tour,bnet,scoring_fn,fxda,Try);
end


%% ====================================================== 函数定义

function gen_new_dataset(Ds_set, dataset, trial)
gen_new_data = true;
switch dataset
    % ================= Small ======================= 节点数 == 边/弧 == 参数 == 最大入度
    case 'Asia',        bnet = mk_asia_bnet;      %     8        8       18        2
end
for i = 1:size(Ds_set,2)
    Ds = Ds_set(i);
    str = sprintf('%s%s',dataset,num2str(Ds));
    fprintf('Generating %s datasets.     Start time [%s]\n',str,datestr(now));
    [~] = acquire_data(str,Ds,trial,gen_new_data,bnet);    % 由数据集产生训练集
    fprintf('- Dataset %s is generated. Finish time [%s]\n',str,datestr(now));
end
end


function execute_algo(Algorithm,Ds_set,dataset,net,N,M,MP,tour,bnet,scoring_fn,fxda,trial)
gen_new_data = false;
gnd = gen_new_data;
sf = scoring_fn;
for i = 1:size(Ds_set,2)
    Ds = Ds_set(i);
    switch Algorithm
        case 'std_score',  get_std_score(Ds,dataset,bnet,trial,sf);                                 % 标准网络得分
        case 'SIGA',       Algo_SIGA(Ds,dataset,net,N,M,MP,bnet,trial,sf,gnd);                         % SIGA
    end
end
end



%% Algorithms

