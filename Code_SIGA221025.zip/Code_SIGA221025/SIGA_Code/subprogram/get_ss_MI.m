function [ss] = get_ss_MI(data,norm_MI,aMI)
% Get super-structure by cal MI between orders
% ���û���Ϣ��������ͼ SS
n = size(data,1);   % #nodes
ss = xor(false(n),diag(true(1,n)));
for i = 1:n-1
    for j = i+1:n
        if norm_MI(i,j) > aMI
            ss(i,j) = true;
            ss(j,i) = true;
        end
    end
end


