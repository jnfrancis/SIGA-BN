function [p,p_a,l_map_MI,l_cnt] = init_pop_ss_MI_randomorder(ss,N,norm_MI)
% 根据 SS 随机初始化个体
% - outputs:
%   l_cnt:SS 中边的个数
%   l_map_MI:SS 个体中的边,按照相对MI进行排序

bns = size(ss,1);       % bnet size
p = cell(1,N);          % population
p(:) = {false(bns)};    % logic init
l_cnt = 0;              % 边的个数
l_map_MI = zeros(0,3);  % 初始化记录个体中的边

% p_a = randn(N,1);       % a*MMI 控制搜索空间
temp_a = randn(5*N,1);          % 取0-1内的正态分布，从5倍的里面挑合适的
% temp_idx = find(temp_a>0 & temp_a<1);
% p_a = temp_a(temp_idx(1:N));    % a*MMI 控制搜索空间
temp_idx = find(temp_a>-0.5 & temp_a<0.5);
p_a = temp_a(temp_idx(1:N))+0.5;    % a*MMI 控制搜索空间


for j = 1 : bns-1
    for k = j+1 :bns
        if ss(j,k)
            % 统计 SS 中的边的个数及连接
            l_cnt = l_cnt + 1;
            l_map_MI(l_cnt,:) = [j,k,norm_MI(j,k)];
        end
    end
end

% 按照第三列排序 l_map_MI. MI 大的在前面
[~,index] = sort(l_map_MI(:,3),'descend');
l_temp = l_map_MI;
for l = 1:l_cnt
    l_temp(l,:) = l_map_MI(index(l),:);
end
l_map_MI = l_temp;

% 按照随机的节点序来初始化
order = zeros(0,bns);
for i = 1:N
    order(i,:) = randperm(bns);
end
for l = 1:l_cnt
    j = l_map_MI(l,1);  k = l_map_MI(l,2);  l_MI = l_map_MI(l,3);
    for i = 1:N
        if l_MI > p_a(i)
            if rand > 0.5
                if order(i,j) < order(i,k)                                  % 处在节点序之前
                    p{i}(j,k) = true;  p{i}(k,j) = false;
                else
                    p{i}(j,k) = false;  p{i}(k,j) = true;
                end
            else
                    p{i}(j,k) = false;  p{i}(k,j) = false;
            end
        end
    end
end

% 按照DAG来初始化
% for l = 1:l_cnt
%     j = l_map_MI(l,1);  k = l_map_MI(l,2);  l_MI = l_map_MI(l,3);
%     for i = 1:N
%         if l_MI > p_a(i)
%             switch(randi(4))
%                 case 1
%                     p{i}(j,k) = true;  p{i}(k,j) = false;
%                 case 2
%                     p{i}(j,k) = false;  p{i}(k,j) = true;
%                 otherwise
%                     p{i}(j,k) = false;  p{i}(k,j) = false;
%             end
%         end
%     end
% end


end