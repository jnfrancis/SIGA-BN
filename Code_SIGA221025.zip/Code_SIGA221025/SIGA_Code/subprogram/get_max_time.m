function [max_time] = get_max_time(n)
% Get maximum CPU time allotted for execution, based on network size.单位秒

% if n<10               % 小数据集
%     max_time = 200;      % 3.3min
% elseif n<30           % Insurance
%     max_time = 2000;     % 33.3min
% elseif n<40           % Alarm
%     max_time = 10000;     % 
% elseif n<50           % Barley
%     max_time = 30000;     % 
% elseif n<60           % Hailfinder 待定
%     max_time = 30000;     % 
% elseif n<80           % Hepar Win95pts
%     max_time = 30000;    % 
% else                  % 超大：Andes Pathfinder
%     max_time = 200000;    % 
% end

% 
if n<10                  % 小
    max_time = 200;      % 3.3min
elseif n<20
    max_time = 600;      % 10min
elseif n<30
    max_time = 2000;     % 33.3min
elseif n<40
    max_time = 4000;     % 1.1h
elseif n<60
    max_time = 8000;     % 2.2h
elseif n<80
    max_time = 12000;    % 3.33h
else                     % 超大
    max_time = 36000;    % 10h
end

end