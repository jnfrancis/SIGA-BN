function [HD] = get_HD(bn1, GTbn)
% ������������֮��ĺ�������-HD
% bn1:  Learned graph
%       0,1,2
% GTbn: True graph
%       0,1

HD = 0;
bns = size(GTbn,1);          % �����С

% for i = 1:bns-1
%     for j = i+1:bns
%         switch GTbn(i,j)
%             case 0
%                 switch GTbn(j,i)
%                     case 0      %     0     0
%                         if ~(bn1(i,j) == 0 && bn1(j,i) == 0)
%                             HD = HD + 1;
%                         end
%                     case 1      %     0     1
%                         if     bn1(i,j) == 0 && bn1(j,i) == 0
%                             HD = HD + 1;
%                         elseif bn1(i,j) == 0 && bn1(j,i) == 1
% %                             HD = HD;
%                         elseif bn1(i,j) == 1 && bn1(j,i) == 0
%                             HD = HD + 0.5;
%                         elseif bn1(i,j) == 2 && bn1(j,i) == 2
%                             HD = HD + 0.5;
%                         end
%                 end
%             case 1      %     1     0
%                 if     bn1(i,j) == 0 && bn1(j,i) == 0
%                     HD = HD + 1;
%                 elseif bn1(i,j) == 0 && bn1(j,i) == 1
%                     HD = HD + 0.5;
%                 elseif bn1(i,j) == 1 && bn1(j,i) == 0
% %                     HD = HD;
%                 elseif bn1(i,j) == 2 && bn1(j,i) == 2
%                     HD = HD + 0.5;
%                 end
%         end
%     end
% end


for i = 1:bns
    for j = 1:bns
        if bn1(i,j) ~= GTbn(i,j)
            HD = HD + 1;
        end
    end
end

end
