function [pop1,pop_a,score1] = selection_MIdss_tournament(N,N2,pop,pop_a,score,tour)
% 选择算子：锦标赛选择 tournament selection（ N1 减少到 N ）
% tour： 锦标赛规模，随机选择tour个个体，选top1
% N2：   种群数量                     N：保留的个体数量
% pop：  种群          选择        pop1：保留的种群
% score：种群得分                score1：保留的种群得分

i = 0;
% 初始化选择之后的种群
% 数量为选择之后的 N0
% 原因：后面进行的交叉操作会生成新的个体，这里仅做初始化
pop1 = cell(1,N2);                  % 保留的个体
pop_a1 = zeros(1,N2);               % 初始化记录个体中的边
score1 = -Inf * ones(1,N2);         % 保留的个体的评分
% norm_score1 = -Inf * ones(1,N);     % 保留的个体的归一化评分

% 选择 N0 个个体
while i < N
    index = ceil(rand(1,tour) *N2);                         % 在 N 个个体中随机选择 tour 个，编号在 index 中
    score_list = score(index);                              % 他们的评分
    best_list = index(find(score_list == max(score_list))); % 取top1，可能会有重复
    winner = best_list(1);                                % 防止重复
    
    i = i+1;                                                % 保留的个体+1
    pop1{i} = pop{winner};
    pop_a1(i) = pop_a(winner);
    score1(i) = score(winner);
%     norm_score1 = norm_score(best_pop);
end
pop_a = pop_a1;

end