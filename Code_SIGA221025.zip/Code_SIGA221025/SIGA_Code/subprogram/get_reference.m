function [l_map] = get_reference(dag,MI)
bns = size(dag,1);
l_map = zeros(0,3);
l_cnt = 0;
for i = 1:bns-1
    for j = i:bns
        if dag(i,j)
            l_cnt = l_cnt + 1;
            l_map(l_cnt,:) = [i,j,MI(i,j)];
        end
    end
end

[~,index] = sort(l_map(:,3),'descend');
l_temp = l_map;
for l = 1:l_cnt
    l_temp(l,:) = l_map(index(l),:);
end
l_map = l_temp;


end