function [pop] = crossover_confidence_v1(N,pop,l_map_MI,conf)
% For each individual: randomly choose its mate in the population, then generate the offspring
% 对每个个体：在种群中随机选择伴侣，然后产生后代
% 置信度选择：统计每一条边在种群中出现的次数，以此作为依据决定这条有争议的边被保留的概率
l_cnt = size(l_map_MI,1);

conf_per = 0.5;

% p_cross 整体所占比例的调整
% 0.5   收敛变好
sum_per = 0.5;

% 支持度参考值
[~,~,conf_list] = find(conf);           % 所有边的支持度

eps = 0.0000001;        % small positive number
conf_min = min(conf_list);
conf_max = max(conf_list);
conf_range = conf_max - conf_min;
norm_conf = (conf-conf_min)/(eps+conf_range); % normalized score


for p1=1:N
    p2 = p1;
    while p1==p2
        % 选择交叉对象
        p2 = randi(N);
    end
    pop{N+p1} = pop{p1};        % 后代编号 N+i
    
    for l=1:l_cnt
        n1 = l_map_MI(l,1);    n2 = l_map_MI(l,2);    l_MI = l_map_MI(l,3);
        if pop{p1}(n1,n2) ~= pop{p2}(n1,n2)         % n1→n2
            p_cross = (1-conf_per) * l_MI + conf_per * norm_conf(n1,n2);
            p_cross = p_cross * sum_per + 0.5*(1-sum_per);
            if p_cross > rand
                pop{N+p1}(n1,n2) = 1;
            else
                pop{N+p1}(n1,n2) = 0;
            end
        end
    end
    
    for l=1:l_cnt
        n1 = l_map_MI(l,2);    n2 = l_map_MI(l,1);    l_MI = l_map_MI(l,3);
        if pop{N+p1}(n2,n1) == 0
            if pop{p1}(n1,n2) == pop{p2}(n1,n2)
                pop{N+p1}(n1,n2) = pop{p1}(n1,n2);
            else                                    % n1→n2
                p_cross = (1-conf_per) * l_MI + conf_per * norm_conf(n1,n2);
                p_cross = p_cross * sum_per + 0.5*(1-sum_per);
                if p_cross > rand
                    pop{N+p1}(n1,n2) = 1;
                else
                    pop{N+p1}(n1,n2) = 0;
                end
            end
        else
            pop{N+p1}(n1,n2) = 0;
        end
    end
    
end
end