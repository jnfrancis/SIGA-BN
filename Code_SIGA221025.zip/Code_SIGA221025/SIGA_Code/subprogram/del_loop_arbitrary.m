function [pop] = del_loop_arbitrary(pop,MP)
% 删除种群中每个个体的环路 using MI

N = size(pop,2);            % 种群个体数
% n = size(pop{1},1);         % 网络大小

for i = 1:N
%     pop{i}(logical(eye(n))) = false;                    % 指向自己的边直接删掉
    [loop,is_dag] = get_loop(pop{i});

    while ~is_dag
        [e0,e1] = find(loop);               % 边的合集：e0 → e1 边起点序列，边终点序列
        loop_size = size(e0,1);             % 环路有几条边
        index = randi(loop_size);

        % 对比：随机删除环路中的一条边
        ii = e0(index);     jj = e1(index);
        pop{i}(ii,jj) = false;
        
        % 思路1：删除 MI 最小的边，边的序列存在e0，e1中
        % ==========================================        
        % 思路2：检查 MI 最小的边的 MI 值，根据值来决定怎么做
        % ================================================
        % 思路3：根据 MI 值将环路中的边分组，小的一组随机删除，大的一组随机反转
        % =================================================================

        [loop,is_dag] = get_loop(pop{i});               % 再次检查有没有环
    end
    %% Constrain Max Fan-in to MP
    pop{i} = naive_limit_parents(MP,pop{i});
end
end
