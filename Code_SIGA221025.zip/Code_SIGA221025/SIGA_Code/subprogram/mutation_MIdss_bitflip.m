function [p] = mutation_MIdss_bitflip(N,l_map_MI,p,p_a,g_best)
% Bit-flip mutation. In case of mutation, given starting allele randomly pick one of the others.
% 单点变异
best_cntl = sum(sum(g_best~=0));        % g_best 个体边的个数
l_cnt = size(l_map_MI,1);
m = 1/l_cnt;

search_space = sum(l_map_MI(:,3) > p_a );
m1 = zeros(1,N);                       % 特殊变异率
indi_cntl = zeros(1,N);
per = 0.7;
for i = 1:N
    indi_cntl(i) = sum(sum(p{i}~=0));
    if indi_cntl(i) == best_cntl
        continue;
    end
    if indi_cntl(i) > best_cntl
        m1(i) = 1/(indi_cntl(i));            % 剪边变异率
    else
        m1(i) = 1/(search_space(i)-indi_cntl(i));    % 加边变异率
    end
end

for l=1:l_cnt
    n1 = l_map_MI(l,1);     n2 = l_map_MI(l,2);     l_MI = l_map_MI(l,3);
    for i=1:N
        e1 = p{i}(n1,n2);       e2 = p{i}(n2,n1);
        % 原始随机操作
        l_val = get_allele(e1, e2);        % 获取边缘分布
        if m >= rand
            l_val_new = mod(l_val + round(rand),3)+1;   % randomly pick one of remaining alleles
            switch l_val_new
                case 1
                    p{i}(n1,n2)=false; p{i}(n2,n1)=false;
                case 2
                    p{i}(n1,n2)=false; p{i}(n2,n1)=true;
                case 3
                    p{i}(n1,n2)=true;  p{i}(n2,n1)=false;
            end
        end
        
        % 按照复杂度来决定加减边
%         if (indi_cntl(i) ~= best_cntl) && (rand>per)
        if (indi_cntl(i) ~= best_cntl) && (rand>per)
            % 单独加减边
            if indi_cntl(i) > best_cntl     % -
                if (m1(i)>=rand*per) && (e1~=0 || e2~=0)
                    p{i}(n1,n2)=false; p{i}(n2,n1)=false;
                end
            else                            % +
                if (m1(i)>=rand*per) && (e1==0 || e2==0)
                    if rand>0.5
                        p{i}(n1,n2)=false; p{i}(n2,n1)=true;
                    else
                        p{i}(n1,n2)=true;  p{i}(n2,n1)=false;
                    end
                end
            end
        end
        
        
    end
end
end