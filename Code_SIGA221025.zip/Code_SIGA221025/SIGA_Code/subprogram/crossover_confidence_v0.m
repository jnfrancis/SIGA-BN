function [pop] = crossover_confidence_v0(N,pop,l_map_MI,conf)
% For each individual: randomly choose its mate in the population, then generate the offspring
% 对每个个体：在种群中随机选择伴侣，然后产生后代
% 置信度选择：统计每一条边在种群中出现的次数，以此作为依据决定这条有争议的边被保留的概率
l_cnt = size(l_map_MI,1);

% 在 Aisa 里效果很好，因为Asia的边占比比较大
% conf = conf / N;

% 参考中位数
[~,~,conf_list] = find(conf);           % 所有边的支持度
% list_size = size(conf_list,1);          % 边的个数（同 2*l_cnt）
% conf_sum = sum(conf_list,'all');        % 和
% conf_mid = median(conf_list,'all');     % 中位数
% conf_avg = conf_sum / list_size;        % 平均数
% conf = conf / (2 * conf_avg);
% conf = conf / (1 * conf_avg);

eps = 0.0000001;        % small positive number
conf_min = min(conf_list);
conf_max = max(conf_list);
range = conf_max - conf_min;
norm_conf = (conf-conf_min)/(eps+range); % normalized score


for p1=1:N
    p2 = p1;
    while p1==p2
        % 选择交叉对象
        p2 = randi(N);
    end
    pop{N+p1} = pop{p1};        % 后代编号 N+i
    
    for l=1:l_cnt
        n1 = l_map_MI(l,1);    n2 = l_map_MI(l,2);    l_MI = l_map_MI(l,3);
        if pop{p1}(n1,n2) ~= pop{p2}(n1,n2)         % n1→n2
             p_cross = 0.5 * l_MI + 0.5 * norm_conf(n1,n2);
             if p_cross > rand
                 pop{N+p1}(n1,n2) = 1;
             else
                 pop{N+p1}(n1,n2) = 0;
             end
        end
    end
    
    for l=1:l_cnt
        n1 = l_map_MI(l,2);    n2 = l_map_MI(l,1);    l_MI = l_map_MI(l,3);
        if pop{N+p1}(n2,n1) == 0
            if pop{p1}(n1,n2) == pop{p2}(n1,n2)
                pop{N+p1}(n1,n2) = pop{p1}(n1,n2);
            else                                    % n1→n2
                p_cross = 0.5 * l_MI + 0.5 * norm_conf(n1,n2);
                if p_cross > rand
                    pop{N+p1}(n1,n2) = 1;
                else
                    pop{N+p1}(n1,n2) = 0;
                end
            end
        else
            pop{N+p1}(n1,n2) = 0;
        end
    end

    
end
end