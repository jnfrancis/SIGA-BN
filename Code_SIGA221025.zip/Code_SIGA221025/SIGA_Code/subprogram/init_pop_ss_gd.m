function [pop,l_map,l_cnt] = init_pop_ss_gd(ss,N)
% 根据 SS 随机初始化 N 个个体的种群 pop
% 想法3：
% 处理孤立节点的尝试：随机建立孤点与其他点的联系
% - outputs:
%   l_cnt:SS 中边的个数
%   l_map:SS 个体中的边

n = size(ss,1);                 % bnet size
pop = cell(1,N);                % population
pop(:) = {false(n)};            % logic init
l_cnt = 0;                      % 边的个数
l_map = zeros(0,2);             % 初始化记录个体中的边

for j = 1 : n-1
    for k = j+1 :n
        if ss(j,k)
            % 统计 SS 中的边的个数及连接
            l_cnt = l_cnt + 1;
            l_map(l_cnt,:) = [j,k];
            for i = 1:N
                % 随机产生边的概率 1/2 ，若产生的边过多则改为 bns
                switch(randi(4))    
                    case 1
                        pop{i}(j,k) = true;  pop{i}(k,j) = false;
                    case 2
                        pop{i}(j,k) = false;  pop{i}(k,j) = true;
                    otherwise
                        pop{i}(j,k) = false;  pop{i}(k,j) = false;
                end
            end
        end
    end
end

% 处理孤点，此行之前未修改
gd = int16.empty(1,0);              % 孤点(gd)：孤点序列
gds = 0;                            % 孤点数(gds)
for i =1:n
    if ~any(ss(i,:)) && ~any(ss(:,i))
        gds = gds+1;
        gd(gds) = i;
    end
end

% 随机分配孤点与其他点的连接，这些边不会参与随后的变异及交叉
for j = 1:gds
    for ii = 1:N
        k = gd(j);          % gd(j)为当前要处理的孤点编号
        while gd(j) == k
            k = randi(n);
        end
        if round(rand)
            pop{ii}(gd(j),k) = true;
        else
            pop{ii}(k,gd(j)) = true;
        end
    end
end

    


end
