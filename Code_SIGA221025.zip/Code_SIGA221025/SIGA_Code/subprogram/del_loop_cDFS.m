function [pop] = del_loop_cDFS(pop,MP)
% 去除邻接矩阵p中的环路
% 检测并删除图中所有的有向边

N = size(pop,2);            % 种群个体数
n = size(pop{1},1);         % 网络大小

white = 0; gray = 1; black = 2;

for i = 1:N
    color = white * ones(1,n);
    pre = zeros(1,n); top = 0;          % 栈的实现，top=0 栈空，top=n 栈满
    
    for u = 1:n
        if color(u) == white
            top = top + 1; pre(top) = u;    % 入栈
            color(u) = gray;
            while top ~= 0
                j = pre(top);               % 读取当前节点j
                child = 0;                  % 判断j是否有儿子
                % 遍历 j 的子孙
                for k = 1:n
                    if pop{i}(j,k) == 1 && color(k) ~=  black     % 有未访问儿子k
                        child = 1;
                        switch color(k)
                            case white      % 未曾访问
                                color(k) = gray;
                                top = top + 1;
                                pre(top) = k;       % 儿子k入栈
                            case gray       % 遇到环路,删除当前边
                                pop{i}(j,k) = 0;
                        end
                        break;
                    end
                end
                if child == 0                       % 无孩子，出栈
                    top = top - 1;
                    color(j) = black;
                end
            end
        end
    end
    %% Constrain Max Fan-in to MP
    pop{i} = naive_limit_parents(MP,pop{i});
end
end

