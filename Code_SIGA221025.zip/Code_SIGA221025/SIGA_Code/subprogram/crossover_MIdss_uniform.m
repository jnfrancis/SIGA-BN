function [p,p_a] = crossover_MIdss_uniform(N,p,p_a,l_map_MI)
% For each individual: randomly choose its mate in the population, then generate the offspring 
% by randomly picking the edge state for each locus from one of the parent individuals.
l_cnt = size(l_map_MI,1);
bns = size(p{1},1);
for i=1:N
    p2 = i;
    while i==p2
        p2 = randi(N);
    end                             % 选择交叉对象
    
    if p_a(p2) < p_a(i)             % 搜索空间小的为 p1
        p1 = i;
    else
        p1 = p2; p2 = i;
    end
    
    % 新个体初始化：编号 N+i
%     p{N+p1}   = p{p1};              % 复制 parent1
    p{N+i} = false(bns);           % 0 初始化
    
    % 新个体的 a 初始化
%     p_a(N+p1) = p_a(p1);                    % 后代的 a 取 p1 的
    p_a(N+i) = (p_a(p1) + p_a(p2))/2;      % 后代的 a 取 p1 p2 的平均值
    
    for l=1:l_cnt
        n1 = l_map_MI(l,1);     n2 = l_map_MI(l,2);
        l_MI = l_map_MI(l,3);
        if l_MI > p_a(N+i)
            if round(rand)
                p{N+i}(n1,n2) = p{p1}(n1,n2);    p{N+i}(n2,n1) = p{p1}(n2,n1);
            else
                p{N+i}(n1,n2) = p{p2}(n1,n2);    p{N+i}(n2,n1) = p{p2}(n2,n1);
            end
        else
            break;
        end
    end
end
end