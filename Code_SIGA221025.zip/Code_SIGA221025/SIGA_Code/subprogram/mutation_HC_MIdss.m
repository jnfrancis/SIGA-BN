function [pop,pop_a,score] = mutation_HC_MIdss(N,pop,pop_a,score)
% 爬山法算子
% 比较现有个体中仅差一个边的个体，选最优进行替换
pop_cpy = pop;
score_cpy = score;
dist_matrix = zeros(N,N)-1;
% 计算每两个图之间的距离矩阵 dist_matrix
for i = 1:N
    for j = i+1:N
        dist = cal_dist(pop{i},pop{j});
        dist_matrix(i,j) = dist;
        dist_matrix(j,i) = dist;
    end
end
for i = 1:N
    L_better_index = find(dist_matrix(i,:) < 2);
    L_better_score = score_cpy(L_better_index);
    if rand<0.7 && max(L_better_score)>score_cpy(i)
        L_better_top_index = find(L_better_score==max(L_better_score));
        L_better_top_1 = L_better_index(L_better_top_index(1));
    else
        L_better_top_1 = i;
    end
    pop{i} = pop_cpy{L_better_top_1};
    score(i) = score(L_better_top_1);
%     norm_score(i) = norm_score(L_better_top_1);
    % 选取替换个体时，复制个体的 a 并随机扩大其搜索空间
    pop_a(i) = (1-rand*0.5) * pop_a(L_better_top_1);
end
end



function [dist] = cal_dist(p1,p2)
% 计算两个dag之间的距离
n = size(p1,1);
xor_g = xor(p1,p2);     % p1,p1中不同的边的个数
dist = sum(sum(xor_g));
for i = 1:n
    for j = i+1:n
        % p1与p2恰好指向相反
        if xor_g(i,j) == 1 && xor_g(j,i) == 1
            dist = dist-1;
        end
    end
end
end