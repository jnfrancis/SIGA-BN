function get_std_score(Ds,dataset,bnet,trial,scoring_fn)
%% 获取标准评分
gen_new_data = false;
str = sprintf('%s%s',dataset,num2str(Ds));
data = acquire_data(str,Ds,trial,gen_new_data,bnet);    % 由数据集产生训练集
bnet.dag = logical(bnet.dag);   % double2boolean DAG conversion
bns = size(bnet.dag,1);         % #nodes
ns = bnet.node_sizes;           % node sizes

% cache_dim = 256*bns;
% cache = score_init_cache(bns,cache_dim);

score = zeros(1,trial);

fprintf('dataset : %s\n', str);
for i = 1:trial
%     [score(i), cache] = score_dags(data{i},ns,{bnet.dag},'scoring_fn',scoring_fn,'cache',cache);
    score(i) = score_dags(data{i},ns,{bnet.dag},'scoring_fn',scoring_fn);
%     fprintf('STD_BIC_score %2d = %11.9f \n', i, score(i));
end

avg_score = mean(score);
fprintf('average STD_BIC_score = %11.3f \n', avg_score);