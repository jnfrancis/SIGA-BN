function [dag,g_best_score,conv,iterations] = siga(ss,data,N,M,MP,scoring_fn,bnet,saved_filename)
% ZWJ原文件名 std_ga_chc_mb_preferv
eval_times = 1;         % 记得保存评分记录
M = M / eval_times;
%% Init
bns = size(bnet.dag,1);   % #nodes
ns = bnet.node_sizes;   % node sizes
conv = struct('f1',zeros(1,M),'se',zeros(1,M),'sp',zeros(1,M),'sc',zeros(1,M));
iterations = M;           % #generations completed in the allotted time

if isempty(find(ss,1))  % input ss has no edges
    [g_best_score,conv] = finalize_output(ss,data,bnet,scoring_fn,M,conv,1);
    dag = {ss};
    return
end

max_realtime = get_max_realtime(bns);   % get max allotted real time
% start = cputime;                % tic
inStart = tic;                                                              % tic 运行时间设置
N2 = bitsll(N,1);       % population size before selection

% cache_dim = 256*bns;          % Cache原始值 256
cache_dim = 4*max(64,bns)*max(64,bns);                                      % Cache设置
cache = score_init_cache(bns,cache_dim);

[pop,l_map] = init_population(ss,N2);                                       % 初始化
pop = make_dag_naive(pop,MP);   % Make-DAG & Naive-Limit-Parents

[score, cache] = score_dags(data,ns,pop,'scoring_fn',scoring_fn,'cache',cache);
[g_best,g_best_score] = get_elite(score,pop); % Get-Elite-Individual

saved_file=fopen(saved_filename,'w');

%% Main Loop
prev_best_score = g_best_score;
cur_stag = 1;
for i=1:M
%     if cputime-start > max_time   % toc
    if toc(inStart) > max_realtime                                          % toc 运行时间设置
        iterations = i;
        [g_best_score,conv] = finalize_output(g_best,data,bnet,scoring_fn,M,conv,iterations);
        break;
    end
    
    [norm_score,~] = normalize(score,g_best_score,true);
    if ~isempty(find(norm_score,1))     % all individuals are not the same
        [p2,score2] = CHC_selection(N,N2,pop,score,norm_score);             % 选择
        p2 = uniform_crossover_learn_elite_mb(N,score2,p2,l_map,bns);       % 创新点1：MB精英级交叉
        p2(N+1:N2) = make_dag_naive(p2(N+1:N2),MP);                         % 去环
    else
        p2 = pop;
    end 
    pop = bitflip_mutation_perfer_V_stru(N2,l_map,p2,cur_stag);             % 创新点2：v结构自适应变异
    pop = make_dag_naive(pop,MP);
    [score,cache] = score_dags(data,ns,pop,'scoring_fn',scoring_fn,'cache',cache);
    [g_best,g_best_score,pop,score] = update_elite(g_best,g_best_score,pop,score);   % Get&Place-Elite-Individual
    conv = update_conv(conv,g_best,g_best_score,bnet.dag,i);
    
    fprintf(saved_file,'%d\n',g_best_score);                                % 将每一次迭代的最佳个体评分写入文件
    
    if g_best_score > prev_best_score
        prev_best_score = g_best_score;
        cur_stag = 1;
    else
        cur_stag = cur_stag + 1;
    end
    iterations = i;
end
dag = {g_best};
fclose(saved_file);
end


%% 函数依赖
function [p_next,score_next] = CHC_selection(N,N2,p,score,norm_score)
% input:p(N),p_prev(N)
% output:p_next(N)
[tmp_score_sort, ind] = sort(score,'descend');
tmp_p_sort = p(ind);
tmp_p_sort = tmp_p_sort(1:N);
tmp_score_sort = tmp_score_sort(1:N);
randIndex = randperm(N);
p_next = tmp_p_sort(randIndex);
score_next = tmp_score_sort(randIndex);
end

function [p] = bitflip_mutation_perfer_V_stru(N,l_map,p,stag)
% Each bit of each individual undergoes mutation with a probability 
% inversely proportional to individual length.
l_cnt = size(l_map,1);
m = 1/l_cnt;            % mutation rate
for l=1:l_cnt
    actual_mute_rate = 0.8; % 0.666
    actual_mute_rate = 0.5 * (exp(-stag/4) + 1);
    j = l_map(l,1);     k = l_map(l,2);
    for i=(N/2):N
        l_val = get_allele(p{i}(j,k),p{i}(k,j));
        if m >= rand
            switch l_val
                case 1 % j k
                    change0 = change_v_jk(l_val, 2, p{i}, j, k);
                    change1 = change_v_jk(l_val, 3, p{i}, j, k);
                    if change0 ~= change1
                        if change0 > change1
                            if rand() <= actual_mute_rate
                                p{i}(j,k)=false; p{i}(k,j)=true;
                            else
                                p{i}(j,k)=true; p{i}(k,j)=false;
                            end
                        else
                            if rand() <= actual_mute_rate
                                p{i}(j,k)=true; p{i}(k,j)=false;
                            else
                                p{i}(j,k)=false; p{i}(k,j)=true;
                            end
                        end
                    else
                        if round(rand) == 0
                            p{i}(j,k)=false; p{i}(k,j)=true;
                        else
                            p{i}(j,k)=true; p{i}(k,j)=false;
                        end
                    end
                case 2 % j<-k
                    change0 = change_v_jk(l_val, 3, p{i}, j, k);
                    change1 = change_v_jk(l_val, 1, p{i}, j, k);
                    if change0 ~= change1
                        if change0 > change1
                            if rand() <= actual_mute_rate
                                p{i}(j,k)=true; p{i}(k,j)=false;
                            else
                                p{i}(j,k)=false; p{i}(k,j)=false;
                            end
                        else
                            if rand() <= actual_mute_rate
                                p{i}(j,k)=false; p{i}(k,j)=false;
                            else
                                p{i}(j,k)=true; p{i}(k,j)=false;
                            end
                        end
                    else
                        if round(rand) == 0
                            p{i}(j,k)=true; p{i}(k,j)=false;
                        else
                            p{i}(j,k)=false; p{i}(k,j)=false;
                        end
                    end
                case 3 % j->k
                    change0 = change_v_jk(l_val, 1, p{i}, j, k);
                    change1 = change_v_jk(l_val, 2, p{i}, j, k);
                    if change0 ~= change1
                        if change0 > change1
                            if rand() <= actual_mute_rate
                                p{i}(j,k)=false; p{i}(k,j)=false;
                            else
                                p{i}(j,k)=false; p{i}(k,j)=true;
                            end
                        else
                            if rand() <= actual_mute_rate
                                p{i}(j,k)=false; p{i}(k,j)=true;
                            else
                                p{i}(j,k)=false; p{i}(k,j)=false;
                            end
                        end
                    else
                        if round(rand) == 0
                            p{i}(j,k)=false; p{i}(k,j)=false;
                        else
                            p{i}(j,k)=false; p{i}(k,j)=true;
                        end
                    end
            end
        end
    end
end
end

function [c] = change_v_jk(l_val,new_type,p_i,j,k)
c = 0;
paj = sum(p_i(:,j));
pak = sum(p_i(:,k));
switch new_type
    case 1
        p_i(j,k)=false; p_i(k,j)=false;
    case 2
        p_i(j,k)=false; p_i(k,j)=true;
    case 3
        p_i(j,k)=true; p_i(k,j)=false;
end
paj_new = sum(p_i(:,j));
pak_new = sum(p_i(:,k));
switch l_val
    case 1
        p_i(j,k)=false; p_i(k,j)=false;
    case 2
        p_i(j,k)=false; p_i(k,j)=true;
    case 3
        p_i(j,k)=true; p_i(k,j)=false;
end
if (paj <= 1 && paj_new > 1) || (paj > 1 && paj_new <= 1) || (paj > 1 && paj_new > 1 && paj~=paj_new)
    c = c+1;
end
if (pak <= 1 && pak_new > 1) || (pak > 1 && pak_new <= 1) || (pak > 1 && pak_new > 1 && pak~=pak_new)
    c = c+1;
end
end

function [s] = uniform_crossover_learn_elite_mb(N,origin_score,s,l_map,node_num)
bestNum = 10;
score_types = sort(unique(origin_score),'descend');
cur_bestNum =  size(score_types, 2);
bestNum = min(bestNum, cur_bestNum);
best10_bn = cell(1,bestNum);
ranking_list = ones(1,N);
for i=1:N
    ranking_list(i) = find(score_types==origin_score(i));
end
for rank=1:bestNum
    for i=1:N
        if ranking_list(i) == rank
            best10_bn{rank} = s{i};
            break;
        end
    end
end
l_cnt = size(l_map,1);
for i=1:N
    j = i;
    while i==j
        j = randi(N);
    end
    s{N+i} = s{i};
    for l=1:l_cnt
        e1 = l_map(l,1);    e2 = l_map(l,2);
        if round(rand)
            s{N+i}(e1,e2) = s{i}(e1,e2);    s{N+i}(e2,e1) = s{i}(e2,e1);
        else
            s{N+i}(e1,e2) = s{j}(e1,e2);    s{N+i}(e2,e1) = s{j}(e2,e1);
        end
    end
    if rand() < 0.5
        rand_best = randi(bestNum);
        rand_node = randi(node_num);
        s{N+i} = copy_markov_blanket(s{N+i}, best10_bn{rand_best}, rand_node, node_num);
    end
end
end

function [g] = copy_markov_blanket(g1, g2, node, nr_of_attr)
g = g1;
g(:,node) = g2(:,node);
for ch=1:nr_of_attr
    if g2(node,ch) == 1
        g(:,ch) = g2(:,ch);
    end
end
end
