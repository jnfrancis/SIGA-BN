function [dag,g_best_score,conv,iterations] = cfxv1_nsga2_3(ss,data,N,M,scoring_fn,bnet,saved_filename)
% GA / Parent Set Crossover / 锦标赛选择 / MI 去环

stop_gate = 50;                 % 判断终止条件
scoring_fn1 = 'bayesian';

%% Init
bns = size(bnet.dag,1);         % #nodes
ns = bnet.node_sizes;           % node sizes
conv = struct('f1',zeros(1,M),'se',zeros(1,M),'sp',zeros(1,M),'sc',zeros(1,M));
iterations = 0;                 % #generations completed in the allotted time

if isempty(find(ss,1))          % input ss has no edges
    [g_best_score,conv] = finalize_output(ss,data,bnet,scoring_fn,M,conv,1);
    dag = {ss};
    return
end

max_time = get_max_time(bns);   % get max allotted cpu time
start = cputime;                % tic
N2 = bitsll(N,1);               % 选择前的种群 population size before selection

% cache_dim = 256*bns;
cache_dim = 1024*bns;
cache = my_score_init_cache(bns,cache_dim);

[MI,norm_MI] = get_MI(data,ns);

[pop,pop_a,l_map_MI] = init_pop_ss_MI(ss,N2,norm_MI);                       %  随机生成初始种群
% pop = make_dag_naive(pop,MP);                       % Make-DAG & Limit-Parents 对种群的父集进行限制，去环

% 利用互信息去环_naive最简单的
% ===========================
pop = del_loop_MI_naive(pop,MI);

[score,cache,score_ll,score_pa] = my_score_dags(data,ns,pop,'scoring_fn',scoring_fn,'cache',cache);
[~,cache,score_bys,~] = my_score_dags(data,ns,pop,'scoring_fn',scoring_fn1,'cache',cache);


population = BN_INDIVIDUAL(pop,score_ll,score_pa,score_bys);

[g_best,g_best_score] = get_best(population.scores,population.dags);            % Get-Elite-Individual 初始化种群最优解
[~,max_score_bys] = get_best(score_bys,population.dags);
final_model = g_best;       stop_cnt = 0;                                   % 保存最后一次的模型进行比较


saved_file=fopen(saved_filename,'a+');

d = struct('m0',1/5,'M0',3/5,'m1',1/10,'M1',1/2);       % healthy diversity interval
dm = d.m0;              dM = d.M0;                      % time-sensitive healthy diversity interval
dms = (d.m1-d.m0)/M;    dMs = (d.M1-d.M0)/M;

%% Main Loop
for i=1:M
    if cputime-start > max_time*6   % toc
        iterations = i;
        [g_best_score,conv] = finalize_output(g_best,data,bnet,scoring_fn,M,conv,iterations);
        break;
    end
    
    [norm_score, ~] = normalize(population.scores,g_best_score,false);
    if ~isempty(find(norm_score,1)) % all individuals are not the same
        [population] = EnvironmentalSelection(population,N);                  % 选择：锦标赛选择
        
%         [elite_set, elite_score] = form_elite_set(elite_gate,N,pop_1,norm_score);     % 获取精英级
%         elite_gate = update_alpha(l_map,g_best,elite_set,elite_gate,dm,dM);
        
        % ====================
%         filename = 'test1.mat';
%         save(filename);
        % ====================
        
%         conf = get_conf(elite_set);
        conf = get_conf(population.dags);
        population = crossover_confidence_nsga2(population,l_map_MI,conf,i,M);                   % 交叉：产生新的后代 N→2N

%         pop_1(N+1:N2) = del_loop_MI_naive(pop_1(N+1:N2),MI);                        % 利用 MI 去环
    else
%         population = population;
    end
    
    pop = bitflip_mutation(N2,l_map_MI,population.dags);                                 % 变异：单点变异
    pop = del_loop_MI_naive(pop,MI);
    
    [score, cache, score_ll, score_pa] = my_score_dags(data,ns,pop,...                             % 评分
        'scoring_fn',scoring_fn,'cache',cache);
    
    [~,cache,score_bys,~] = my_score_dags(data,ns,pop,'scoring_fn',scoring_fn1,'cache',cache);
    
    [g_best,g_best_score,pop,score] = update_elite(g_best,g_best_score,pop,score);   % Get&Place-Elite-Individual
    conv = update_conv(conv,g_best,g_best_score,bnet.dag,i);
    
    population = BN_INDIVIDUAL(pop,score_ll,score_pa,score_bys);
    
    max_score_bys = max(max(score_bys),max_score_bys);
    
%     fprintf(saved_file,'%d\n',g_best_score);
    fprintf(saved_file,'%d,%d\n',g_best_score,max_score_bys);                                % 将每一次迭代的最佳个体评分写入文件

    iterations = i;
    
%     if final_model == g_best                                % 判断终止条件
%         stop_cnt = stop_cnt + 1;
%     else
%         stop_cnt = 0;
%         final_model = g_best;
%     end
%     if stop_cnt >= stop_gate
%         break;
%     end
    

    dm = dm+dms;    dM = dM+dMs;    % healthy diversity interval update

end

dag = {g_best};
fclose(saved_file);

end

function [population] = pop2individual(pop,score_ll,score_pa)
    population.obj = [-score_ll,score_pa];
    population.con = 0;
    population.dag = pop;
    population.score = score_ll-score_pa;
end
