function [dag,g_best_score,conv,iterations] = ga_tour_colorDFS(ss,data,N,M,scoring_fn,bnet,tour,saved_filename)
% GA / Parent Set Crossover / 锦标赛选择 / colored DFS 去环

stop_gate = 50;                 % 判断终止条件

%% Init
bns = size(bnet.dag,1);         % #nodes
ns = bnet.node_sizes;           % node sizes
conv = struct('f1',zeros(1,M),'se',zeros(1,M),'sp',zeros(1,M),'sc',zeros(1,M));
iterations = 0;                 % #generations completed in the allotted time

if isempty(find(ss,1))          % input ss has no edges
    [g_best_score,conv] = finalize_output(ss,data,bnet,scoring_fn,M,conv,1);
    dag = {ss};
    return
end

max_time = get_max_time(bns);   % get max allotted cpu time
start = cputime;                % tic
N2 = bitsll(N,1);               % 选择前的种群 population size before selection

cache_dim = 256*bns;
cache = score_init_cache(bns,cache_dim);

[pop,l_map] = init_pop_ss(ss,N2);                                           %  随机生成初始种群
% pop = make_dag_naive(pop,MP);                       % Make-DAG & Limit-Parents 对种群的父集进行限制，去环

% colored DFS 去环
% ================
pop = colored_DFS_all(pop);

[score,cache] = score_dags(data,ns,pop,'scoring_fn',scoring_fn,'cache',cache);
[g_best,g_best_score] = get_best(score,pop);            % Get-Elite-Individual 初始化种群最优解
final_model = g_best;       stop_cnt = 0;                                   % 保存最后一次的模型进行比较


saved_file=fopen(saved_filename,'w');

%% Main Loop
for i=1:M
    if cputime-start > max_time*6   % toc
        iterations = i;
        [g_best_score,conv] = finalize_output(g_best,data,bnet,scoring_fn,M,conv,iterations);
        break;
    end
    
    [norm_score, ~] = normalize(score,g_best_score,true);
    if ~isempty(find(norm_score,1)) % all individuals are not the same
        pop_1 = selection_tournament(N,N2,pop,score,tour);                      % 选择：锦标赛选择
        pop_1 = uniform_crossover(N,pop_1,l_map);                               % 繁衍,交叉产生新的后代 N→2N
%         pop_1(N+1:N2) = del_loop_MI_naive(pop_1(N+1:N2),MI);                      % 利用 MI 去环
    else
        pop_1 = pop;
    end
    
    pop = bitflip_mutation(N2,l_map,pop_1);                                     % 单点变异
    pop = colored_DFS_all(pop);
    
    [score, cache] = score_dags(data,ns,pop,'scoring_fn',scoring_fn,'cache',cache);
    [g_best,g_best_score,pop,score] = update_elite(g_best,g_best_score,pop,score);   % Get&Place-Elite-Individual
    conv = update_conv(conv,g_best,g_best_score,bnet.dag,i);
    
    fprintf(saved_file,'%d\n',g_best_score);                                % 将每一次迭代的最佳个体评分写入文件

    iterations = i;
    if final_model == g_best                                % 判断终止条件
        stop_cnt = stop_cnt + 1;
    else
        stop_cnt = 0;
        final_model = g_best;
    end
%     if stop_cnt >= stop_gate
%         break;
%     end
    
end

dag = {g_best};
fclose(saved_file);

end



