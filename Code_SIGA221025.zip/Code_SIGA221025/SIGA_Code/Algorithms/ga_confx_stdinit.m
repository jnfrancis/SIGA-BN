function [dag,g_best_score,conv,iterations] = ga_confx_stdinit(ss,data,N,M,MP,scoring_fn,bnet,tour,saved_filename)
% GA / Parent Set Crossover / 锦标赛选择 / MI 去环

%% Init
bns = size(bnet.dag,1);         % #nodes
ns = bnet.node_sizes;           % node sizes
conv = struct('f1',zeros(1,M),'se',zeros(1,M),'sp',zeros(1,M),'sc',zeros(1,M));
iterations = 0;                 % #generations completed in the allotted time

if isempty(find(ss,1))          % input ss has no edges
    [g_best_score,conv] = finalize_output(ss,data,bnet,scoring_fn,M,conv,1);
    dag = {ss};
    return
end

max_time = get_max_time(bns);   % get max allotted cpu time
start = cputime;                % tic
N2 = bitsll(N,1);               % 选择前的种群 population size before selection

cache_dim = 256*bns;
cache = score_init_cache(bns,cache_dim);

[MI,norm_MI] = get_MI(data,ns);

[pop,l_map_MI] = init_MI_stdinit(ss,N2,norm_MI);                       %  随机生成初始种群
pop = make_dag(pop,MP);             % 对种群的父集进行限制，去环

% 利用互信息去环_naive最简单的
% ===========================
% pop = del_loop_MI_naive(pop,MI);

[score,cache] = score_dags(data,ns,pop,'scoring_fn',scoring_fn,'cache',cache);
[g_best,g_best_score] = get_best(score,pop);            % Get-Elite-Individual 初始化种群最优解
% final_model = g_best;       stop_cnt = 0;                                   % 保存最后一次的模型进行比较


saved_file=fopen(saved_filename,'w');
M = M-1;
fprintf(saved_file,'%d\n',g_best_score);

%% Main Loop
for i=1:M
    if cputime-start > max_time*6   % toc
        iterations = i;
        [g_best_score,conv] = finalize_output(g_best,data,bnet,scoring_fn,M,conv,iterations);
        break;
    end
    
    [norm_score, ~] = normalize(score,g_best_score,false);
    if ~isempty(find(norm_score,1)) % all individuals are not the same
        [pop_1,~] = selection_tournament(N,N2,pop,score,tour);                  % 选择：锦标赛选择

        conf = get_conf(pop_1(1:N));
        pop_1 = crossover_confidence_v1(N,pop_1,l_map_MI,conf);                   % 交叉：产生新的后代 N→2N

%         pop_1(N+1:N2) = del_loop_MI_naive(pop_1(N+1:N2),MI);                        % 利用 MI 去环
    else
        pop_1 = pop;
    end
    
    pop = bitflip_mutation(N2,l_map_MI,pop_1);                                 % 变异：单点变异
    pop = del_loop_MI_naive(pop,MI);
    
    [score, cache] = score_dags(data,ns,pop,...                             % 评分
        'scoring_fn',scoring_fn,'cache',cache);
    
    [g_best,g_best_score,pop,score] = update_elite(g_best,g_best_score,pop,score);   % Get&Place-Elite-Individual
    conv = update_conv(conv,g_best,g_best_score,bnet.dag,i);
    
    fprintf(saved_file,'%d\n',g_best_score);                                % 将每一次迭代的最佳个体评分写入文件

    iterations = i;



end

dag = {g_best};
fclose(saved_file);

end



