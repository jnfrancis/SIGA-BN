function [dag,g_best_score,conv,iterations] = cfxv1_nsga2(ss,data,N,M,scoring_fn,bnet,saved_filename)
% GA / Parent Set Crossover / 锦标赛选择 / MI 去环

stop_gate = 50;                 % 判断终止条件

%% Init
bns = size(bnet.dag,1);         % #nodes
ns = bnet.node_sizes;           % node sizes
conv = struct('f1',zeros(1,M),'se',zeros(1,M),'sp',zeros(1,M),'sc',zeros(1,M));
iterations = 0;                 % #generations completed in the allotted time

if isempty(find(ss,1))          % input ss has no edges
    [g_best_score,conv] = finalize_output(ss,data,bnet,scoring_fn,M,conv,1);
    dag = {ss};
    return
end

max_time = get_max_time(bns);   % get max allotted cpu time
start = cputime;                % tic
N2 = bitsll(N,1);               % 选择前的种群 population size before selection

% cache_dim = 256*bns;
cache_dim = 1024*bns;
cache = my_score_init_cache(bns,cache_dim);

[MI,norm_MI] = get_MI(data,ns);

[pop,pop_a,l_map_MI] = init_pop_ss_MI(ss,N2,norm_MI);                       %  随机生成初始种群
% pop = make_dag_naive(pop,MP);                       % Make-DAG & Limit-Parents 对种群的父集进行限制，去环

% 利用互信息去环_naive最简单的
% ===========================
pop = del_loop_MI_naive(pop,MI);

% [score,cache,score_ll,score_pa] = my_score_dags(data,ns,pop,'scoring_fn',scoring_fn,'cache',cache);
% [~,cache,std_x1,std_x2] = my_score_dags(data,ns,{bnet.dag},'scoring_fn',scoring_fn,'cache',cache);


[~,cache,score_ll,~] = my_score_dags(data,ns,pop,'scoring_fn','bic','cache',cache);
[~,cache,~,score_pa] = my_score_dags(data,ns,pop,'scoring_fn','mit','cache',cache);
[~,cache,std_x1,~] = my_score_dags(data,ns,{bnet.dag},'scoring_fn','bic','cache',cache);
[~,cache,~,std_x2] = my_score_dags(data,ns,{bnet.dag},'scoring_fn','mit','cache',cache);

max_ll = max(max(-score_ll));
max_pa = max(max(score_pa));

% [norm_score_ll, ~] = normalize(-score_ll,max_ll,false);
% [norm_score_pa, ~] = normalize(score_pa,max_pa,false);

% score_pa = score_pa / 3;
% std_x2 = std_x2 /3;

population = BN_INDIVIDUAL(pop,score_ll,score_pa);
% population = BN_INDIVIDUAL(pop,-norm_score_ll,norm_score_pa);

% % 尝试使用边的个数作为惩罚项
% edgeNum = [];
% for j = 1:size(pop,2)
%     edgeNum(j) = sum(pop{j}, 'all');
% end
% population = BN_INDIVIDUAL(pop,score_ll,edgeNum);

[population,FrontNo] = EnvironmentalSelection(population,N);               % 选择：NSGAII 环境选择

[g_best,g_best_score] = get_best(population.scores,population.dags);       % Get-Elite-Individual 初始化种群最优解
% final_model = g_best;       stop_cnt = 0;                                  % 保存最后一次的模型进行比较

saved_file=fopen(saved_filename,'w');

%% Main Loop
for i=1:M
    if cputime-start > max_time*6   % toc
        iterations = i;
        [g_best_score,conv] = finalize_output(g_best,data,bnet,scoring_fn,M,conv,iterations);
        break;
    end
    
    [norm_score, ~] = normalize(population.scores,g_best_score,false);
    if ~isempty(find(norm_score,1)) % all individuals are not the same
        
        % 画图：帕累托前沿
        draw_objs(population, std_x1, std_x2);
        output_pop_accuracy(population,FrontNo,bnet,MI,g_best,i,g_best_score,std_x1,std_x2);
        
        [~,conf] = get_conf(population.dags);
        population = crossover_confidence_nsga2(population,l_map_MI,conf,i,M);  % 交叉：产生新的后代 N→2N

    else
%         population = population;
    end
    
    pop = bitflip_mutation(N2,l_map_MI,population.dags);                   % 变异：单点变异
    pop = del_loop_MI_naive(pop,MI);
    
%     [score, cache, score_ll, score_pa] = my_score_dags(data,ns,pop,...     % 评分
%         'scoring_fn',scoring_fn,'cache',cache);


    [~,cache,score_ll,~] = my_score_dags(data,ns,pop,'scoring_fn','bic','cache',cache);
    [~,cache,~,score_pa] = my_score_dags(data,ns,pop,'scoring_fn','mit','cache',cache);
    score = score_ll - score_pa;
    
    max_ll = max(max(-score_ll));
    max_pa = max(max(score_pa));
    
    % normalize
%     [norm_score_ll, ~] = normalize(-score_ll,max_ll,false);
%     [norm_score_pa, ~] = normalize(score_pa,max_pa,false);
%     [score,~] = normalize(score,max(score),false);
    
%     score_pa = score_pa / 3;
    
    [g_best,g_best_score,pop,score] = update_elite(g_best,g_best_score,pop,score);   % Get&Place-Elite-Individual
    conv = update_conv(conv,g_best,g_best_score,bnet.dag,i);
    
    
    population = BN_INDIVIDUAL(pop,score_ll,score_pa);
%     population = BN_INDIVIDUAL(pop,-norm_score_ll,norm_score_pa);

%     % 尝试使用边的个数作为惩罚项
%     edgeNum = [];
%     for j = 1:size(pop,1)
%         edgeNum(j) = sum(pop{j}, 'all');
%     end
%     population = BN_INDIVIDUAL(pop,score_ll,edgeNum);

    fprintf(saved_file,'%d\n',g_best_score);                               % 将每一次迭代的最佳个体评分写入文件

    iterations = i;
    [population,FrontNo] = EnvironmentalSelection(population,N);           % 选择：锦标赛选择

end

dag = {g_best};
fclose(saved_file);

end

% function [population] = pop2individual(pop,score_ll,score_pa)
%     population.obj = [-score_ll,score_pa];
%     population.con = 0;
%     population.dag = pop;
%     population.score = score_ll-score_pa;
% end

function [] = draw_objs(population, std_x1, std_x2)
    clf();
    x1 = population.objs;
    x2 = x1(:,2);
    x1 = x1(:,1);
    
    scatter(x1,x2);
    hold on;
    scatter(-std_x1,std_x2, 'r');
    drawnow;
end

function [] = output_pop_accuracy(population,FrontNo,bnet,MI,g_best,i,g_best_score,std_x1,std_x2)

    fstpop = population(FrontNo == 1);
    [~,conf_norm] = get_conf(fstpop.dags);                              % 帕累托最优前沿的 spt，用于交叉
%         conf_norm(conf_norm > min(conf_norm(conf_norm > 0))) = 1;
%         conf_norm(conf_norm < 1) = 0;
    fstspt = conf_norm;
    fstspt(conf_norm > 0) = 1;                              % 只要有的边都考虑进去
    fstspt = cell2mat(del_loop_MI_naive({fstspt},MI));      % 使解可行
    hds = [];
    hds1 = [];
    hds2 = [];
    dags = population.dags;
    for j = 1:100
        hds(j) = get_HD(bnet.dag, cell2mat(dags(j)));
    end

    dags = fstpop.dags;
    for j = 1:size(fstpop,2)
        hds1(j) = get_HD(bnet.dag, cell2mat(dags(j)));
    end

    fstpop = population(FrontNo == 2);
    dags = fstpop.dags;
    for j = 1:size(fstpop,2)
        hds2(j) = get_HD(bnet.dag, cell2mat(dags(j)));
    end
    hds = sort(hds,'ascend');
    hds1 = sort(hds1,'ascend');
    hds2 = sort(hds2,'ascend');

    fprintf('-------- PoP: %3d  %3d  -%3d   -----%3d -----\n', hds(1:2), hds(size(hds,2)), i);
    fprintf(' G*%3d   1st: %3d  %3d  -%3d   gbst %6.3f\n', get_HD(bnet.dag, g_best), hds1(1:2), hds1(size(hds1,2)), g_best_score);
    fprintf(' spt%3d  2nd: %3d  %3d  -%3d   std: %6.3f\n', get_HD(bnet.dag, fstspt), hds2(1:2), hds2(size(hds2,2)), std_x1-std_x2);


end